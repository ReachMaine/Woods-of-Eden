<?php

//add_action( 'after_setup_theme', 'reach_child_theme_setup' );


// function reach_themes_child_theme_setup() {

// }
// add_action( 'init', 'be_restore_default_gallery');

  require_once(get_stylesheet_directory().'/custom/branding.php');
  require_once(get_stylesheet_directory().'/custom/language.php');
  require_once(get_stylesheet_directory().'/custom/reach_CTAs.php');
  require_once(get_stylesheet_directory().'/custom/oshine.php');

?>
